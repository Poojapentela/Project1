import java.util.Scanner;
public class SecondDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter an integer: ");
        int num = scanner.nextInt();
        String hex = Integer.toHexString(num);
        String oct = Integer.toOctalString(num);
        String bin = Integer.toBinaryString(num);
        System.out.println("Hexadecimal: " + hex);
        System.out.println("Octal: " + oct);
        System.out.println("Binary: " + bin);

        scanner.close();
    }
}
