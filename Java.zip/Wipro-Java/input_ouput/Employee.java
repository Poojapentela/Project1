package input_ouput;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Employee {
    private File file;

    public Employee(String filePath) {
        file = new File(filePath);
    }

    public void condition(int option) {
        switch (option) {
            case 1:
                writeEmployeeDetails();
                break;

            case 2:
                displayFileContents();
                break;

            case 3:
                System.out.println("Exiting");
                System.exit(0);

            default:
                System.out.println("Invalid option");
                break;
        }
    }

    private void writeEmployeeDetails() {
        try (Scanner sc = new Scanner(System.in);
             FileWriter fw = new FileWriter(file, true);
             BufferedWriter bw = new BufferedWriter(fw)) {

            System.out.println("Enter employee id:");
            int id = sc.nextInt();
            sc.nextLine();
            bw.write("Employee ID: " + id);
            bw.newLine();

            System.out.println("Enter the name of employee:");
            String name = sc.nextLine();
            bw.write("Name: " + name);
            bw.newLine();

            System.out.println("Enter the age:");
            int age = sc.nextInt();
            sc.nextLine(); 
            bw.write("Age: " + age);
            bw.newLine();

            System.out.println("Enter the salary:");
            double salary = sc.nextDouble();
            sc.nextLine(); 
            bw.write("Salary: " + salary);
            bw.newLine();

            System.out.println("Employee details written to file successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void displayFileContents() {
        try (FileReader fr = new FileReader(file);
             BufferedReader br = new BufferedReader(fr)) {

            String line;
            while ((line = br.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Employee employee = new Employee("C:\\Users\\pooja\\OneDrive\\Desktop\\input.txt");
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("Enter the option: 1 to add employee details, 2 to display file contents, 3 to exit");
            int option = sc.nextInt();
            employee.condition(option);
        }
    }
}
