import java.util.Scanner;
public class FirstDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements ");
        int n=sc.nextInt();
        int[] arr1=new int[n];
        for(int i=0;i<n;i++)
        {
            arr1[i]=sc.nextInt();
        }
        int maxElement=arr1[0];
        int minElement=arr1[0];
        for (int i = 0; i < arr1.length; i++) {
            if (arr1[i] > maxElement) {
                maxElement = arr1[i];
            }
            if (arr1[i] < minElement) {
                minElement = arr1[i];
            }
        }
        System.out.println("Maximum element: " + maxElement);
        System.out.println("Minimum element: " + minElement);

        }
    }
