import java.util.Scanner;
import java.util.Arrays;
public class FourthDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the number of elements: ");
        int n = sc.nextInt();
        int[] arr1 = new int[n];
        for (int i = 0; i < n; i++) {
            arr1[i] = sc.nextInt();
        }
        Arrays.sort(arr1);
        int uniqueIndex = 0; 
        for (int i = 0; i < n; i++) {
              if (i == n - 1 || arr1[i] != arr1[i + 1]) {
                arr1[uniqueIndex++] = arr1[i];
            }
        }
        for (int i = 0; i < uniqueIndex; i++) {
            System.out.print(arr1[i] + " ");
        }
    }
}
