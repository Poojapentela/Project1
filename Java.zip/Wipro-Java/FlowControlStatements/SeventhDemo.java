import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class SeventhDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int count=0;
        for (int i = 1; i <= num1; i++) {
            if ( num1%i== 0) {
                count=count+1;
            }

        }
        if(count==2)
        {
            System.out.println("Prime number");
        }
        else
        {
            System.out.println("not a prime number");
        }

    }
}
