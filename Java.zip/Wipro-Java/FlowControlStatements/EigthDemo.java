import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class EigthDemo {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int count=0;
       while(num1!=0)
       {
        int r=num1%10;
        count=count+r;
        num1=num1/10;
       }
       System.out.println(count);

    }
}
