import java.util.Scanner;

public class ThridDemo {
    
    private int Addition(int num1,int num2) {
        return num1+ num2;
    }
    
    public static void main(String[] args) {
        ThridDemo ob = new ThridDemo();
        Scanner sc = new Scanner(System.in);
        int num1 = sc.nextInt();
        int num2=sc.nextInt();
        System.out.println("The sum of "+num1+" and "+num2+" is "+ob.Addition(num1,num2));
    }
}
