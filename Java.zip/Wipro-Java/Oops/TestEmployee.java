package Oops;

public class TestEmployee {

	public static void main(String[] args) {
		 Employee emp = new Employee(2024, 50000.0, "12345A", "pooja");
	        emp.display();

	}

}
