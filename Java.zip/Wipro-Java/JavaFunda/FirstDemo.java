import java.util.Scanner;
public class FirstDemo {
    private String Addition() {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        String str1 = sc.nextLine();
        return str + " Technologies " + str1;
    }
    
    public static void main(String[] args) {
        FirstDemo ob = new FirstDemo();
        System.out.println(ob.Addition());
    }
}
