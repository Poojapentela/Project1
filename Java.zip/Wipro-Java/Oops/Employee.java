package Oops;

class Employee extends Person{

		    public int year; 
		    public double salary;
		    public String num;
		    
		    public Employee(int year, double salary, String num, String name) {
		        super(name);
		        this.year = year;
		        this.salary= salary;
		        this.num = num;
		    }
		    
		    public void setYear(int year) {
		        this.year= year;
		    }
		    
		    public int getYear() {
		        return year;
		    }
		    
		    public void setPrice(double salary) {
		        this.salary = salary;
		    }
		    
		    public double getPrice() {
		        return salary;
		    }
		    
		    public void setStock(String num) {
		        this.num = num;
		    }
		    
		    public String getStock() {
		        return num;
		    }
		    
		    public void display() {
		        System.out.println("Author Name: " + super.name);
		        System.out.println("Book Name: " + this.num);
		        System.out.println("Book Price: " + this.year);
		        System.out.println("Books in Stock: " + this.salary);
		    }
		   
	}


