package Oops;

import java.util.Scanner;

public class StringReturnTwo {

	public static void main(String[] args) {
       Scanner sc = new Scanner(System.in); 
        System.out.print("Enter a string: ");
        String str2= sc.next();
        System.out.print("Enter a string2: ");
        String str = sc.next();
        if(str2.length()==str.length())
        {
             System.out.println("not possible");
        }
        else
        {
        	System.out.println(str2+str+str2);
        }

	}

}
