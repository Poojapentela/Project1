package Oops;

import java.util.Scanner;

public class StringReturn3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String str1 = sc.next();
        if (str1.length() > 1 && str1.startsWith("x") && str1.endsWith("x")) {
            System.out.println(str1.substring(1, str1.length() - 1));
        } else {
            System.out.println(str1);
        }
        
    }
}
