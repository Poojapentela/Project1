package Oops;

public class Calculator {
	public int num1;
	public int num2;
	public double n1;
	public double n2;
	
	static int powerInt(int num1,int num2)
	{
		return (int) Math.pow(num1, num2);
	}
	static double powerDouble(double n1,double n2)
	{
		return Math.pow(n1, n2);
	}
	public static void main(String args[])
	{
		Calculator c=new Calculator();
		System.out.println(c.powerInt(2, 2));
		System.out.println(c.powerDouble(2.5, 2.5));
	}
	
     
}
