package Oops;

import java.util.Scanner;

public class StringReturn5 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a string: ");
        String str1 = sc.next();
        System.out.print("Enter the number of characters to print from the end: ");
        int n = sc.nextInt();
        int h=n;
        String s="";
        while(h>0)
        {
        if (n <= str1.length()) {
            s=str1.substring(str1.length() - n)+s;;
        } else {
            System.out.println("Number of characters exceeds the length of the string.");
        }
        h=h-1;
        }
        System.out.println(s);
    }
}
