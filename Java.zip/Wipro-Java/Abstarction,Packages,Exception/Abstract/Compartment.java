public abstract class Compartment {

    public abstract String notice();
}
class FirstClass extends Compartment {

    @Override
    public String notice() {
        return "First";
    }
}
class Ladies extends Compartment {

    @Override
    public String notice() {
        return "Ladies";
    }
}
class General extends Compartment {

    @Override
    public String notice() {
        return "General";
    }
}
class Luggage extends Compartment {

    @Override
    public String notice() {
        return "Luggage";
    }
}