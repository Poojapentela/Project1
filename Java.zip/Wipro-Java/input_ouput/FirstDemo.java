package input_ouput;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FirstDemo {
    public static void main(String[] args) throws IOException {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the file path:");
        String filePath = sc.next();
        FileWriter writer = new FileWriter(filePath);
        System.out.println("Enter content to add to the file:");
        String str = sc.next();
        writer.write(str);
        writer.close();

        int count = 0;
        System.out.println("Enter character to search in the file:");
        char ch = sc.next().charAt(0);
        sc.close();

        FileReader reader = new FileReader(filePath); 
        BufferedReader br = new BufferedReader(reader);
        int c;
        while ((c = br.read()) != -1) {
            char character = (char) c;
            if (character == ch) {
                count++;
            }
        }
        br.close();
        reader.close(); 

        System.out.println("The character '" + ch + "' appears " + count + " times in the file.");
    }
}
