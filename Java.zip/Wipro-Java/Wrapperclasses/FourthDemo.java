public class FourthDemo implements Cloneable {
    private Integer employeeId;
    private String employeeName;
    private Double salary;
    public FourthDemo(Integer employeeId, String employeeName, Double salary) {
        this.employeeId = employeeId;
        this.employeeName = employeeName;
        this.salary = salary;
    }

    public Integer getEmployeeId() {
        return employeeId;
    }
    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }

    public String getEmployeeName() {
        return employeeName;
    }

    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }
    public void printDetails() {
        System.out.println("Employee ID: " + employeeId);
        System.out.println("Employee Name: " + employeeName);
        System.out.println("Salary: " + salary);
    }
    @Override
    public FourthDemo clone() {
        try {
            return (FourthDemo) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }
    }
   public static void main(String[] args) {
        FourthDemo emp1 = new FourthDemo(101, "pooja", 50000.0);
        System.out.println("Employee Details:");
        emp1.printDetails();
        FourthDemo emp2 = emp1.clone();
        emp2.setEmployeeId(102);
        emp2.setEmployeeName("vamsi");
        emp2.setSalary(60000.0);
        System.out.println("\nCloned Employee Details:");
        emp2.printDetails();
    }
}
