import java.util.Scanner;

public class SecondDemo {
    
    private String Addition() {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        return "Welcome" + str;
    }
    
    public static void main(String[] args) {
        SecondDemo ob = new SecondDemo();
        System.out.println(ob.Addition());
    }
}

